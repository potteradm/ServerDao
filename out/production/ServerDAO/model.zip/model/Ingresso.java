package model;

import java.io.Serializable;

public class Ingresso implements Serializable {
    private int codigo;
    private int quantidaDeUsos;
    private int usados;
    private int tiposdeingresso_codigo;
    private int transacoes_codigo;
    private int usuarios_codigo;

    public Ingresso(int codigo, int quantidaDeUsos, int usados, int tiposdeingresso_codigo, int transacoes_codigo, int usuarios_codigo) {
        this.codigo = codigo;
        this.quantidaDeUsos = quantidaDeUsos;
        this.usados = usados;
        this.tiposdeingresso_codigo = tiposdeingresso_codigo;
        this.transacoes_codigo = transacoes_codigo;
        this.usuarios_codigo = usuarios_codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getQuantidaDeUsos() {
        return quantidaDeUsos;
    }

    public void setQuantidaDeUsos(int quantidaDeUsos) {
        this.quantidaDeUsos = quantidaDeUsos;
    }

    public int getUsados() {
        return usados;
    }

    public void setUsados(int usados) {
        this.usados = usados;
    }

    public int getTiposdeingresso_codigo() {
        return tiposdeingresso_codigo;
    }

    public void setTiposdeingresso_codigo(int tiposdeingresso_codigo) {
        this.tiposdeingresso_codigo = tiposdeingresso_codigo;
    }

    public int getTransacoes_codigo() {
        return transacoes_codigo;
    }

    public void setTransacoes_codigo(int transacoes_codigo) {
        this.transacoes_codigo = transacoes_codigo;
    }

    public int getUsuarios_codigo() {
        return usuarios_codigo;
    }

    public void setUsuarios_codigo(int usuarios_codigo) {
        this.usuarios_codigo = usuarios_codigo;
    }
}
